# Expense-Tracker-Android
### CPR E 388 - Embedded Systems 2
A proposed final project

## Requirements
* The user can create, update, and delete expenses (10 pts)
* The user can create, update, and delete expense categories (10 pts)
* Persist expenses and authenticate with Firebase (20pts)
* Create graphs for expenses for certain categories and time frames (20pts)
* Send a reminder when bills are due with notifications (20 pts)
* Allow to set currency and monthly budget. Settings (10 pts)
* Allow sorting of expenses by category, date, amount, etc. (10pts)
