package edu.iastate.adamcorp.expensetracker.ui.viewholders;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ExpenseCategoryHolder extends RecyclerView.ViewHolder {
    public ExpenseCategoryHolder(@NonNull View itemView) {
        super(itemView);
    }
}
