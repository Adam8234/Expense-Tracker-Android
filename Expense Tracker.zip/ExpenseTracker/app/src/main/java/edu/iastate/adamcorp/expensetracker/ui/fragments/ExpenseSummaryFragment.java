package edu.iastate.adamcorp.expensetracker.ui.fragments;

import dagger.android.support.DaggerFragment;

public class ExpenseSummaryFragment extends DaggerFragment {
}
