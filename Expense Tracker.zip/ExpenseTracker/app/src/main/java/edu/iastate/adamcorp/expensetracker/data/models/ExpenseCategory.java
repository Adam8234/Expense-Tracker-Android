package edu.iastate.adamcorp.expensetracker.data.models;

public class ExpenseCategory {
    private String name;
}
